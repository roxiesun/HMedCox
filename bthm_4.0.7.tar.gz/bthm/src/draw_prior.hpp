//
//  draw_prior.hpp
//  
//
//  Created by Rongqian Sun on 20/11/2023.
//

#ifndef draw_prior_hpp
#define draw_prior_hpp

#include <stdio.h>

#endif /* draw_prior_hpp */
